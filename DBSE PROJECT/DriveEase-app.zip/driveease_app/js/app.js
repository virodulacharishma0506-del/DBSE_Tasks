/* =========================================================
   DriveEase — app.js
   Frontend "database" simulated with localStorage.
   Sections: Data, Storage helpers, Vehicles, Auth, Wishlist,
   Reviews, Notifications, Bookings, Coupons, Theme,
   Global UI, Recommendations, Compare, Admin, Page renderers
   ========================================================= */

/* ---------- 1. Base vehicle data (seed) ---------- */
const DEFAULT_CARS = [
{id:1,brand:"Hyundai",model:"Creta",type:"SUV",price:2200,seats:5,trans:"Automatic",fuel:"Petrol",rating:4.8,image:"assets/cars/creta.png",demand:"high"},
{id:2,brand:"Honda",model:"City",type:"Sedan",price:1900,seats:5,trans:"Automatic",fuel:"Petrol",rating:4.7,image:"assets/cars/honda-city.png",demand:"normal"},
{id:3,brand:"Tata",model:"Nexon EV",type:"SUV",price:2100,seats:5,trans:"Automatic",fuel:"Electric",rating:4.9,image:"assets/cars/nexon-ev.png",demand:"high"},
{id:4,brand:"Maruti",model:"Swift",type:"Hatchback",price:1400,seats:5,trans:"Manual",fuel:"Petrol",rating:4.6,image:"assets/cars/swift.png",demand:"normal"},
{id:5,brand:"Toyota",model:"Innova Hycross",type:"SUV",price:3200,seats:7,trans:"Automatic",fuel:"Hybrid",rating:4.9,image:"assets/cars/innova-hycross.png",demand:"high"},
{id:6,brand:"BMW",model:"3 Series",type:"Luxury",price:6500,seats:5,trans:"Automatic",fuel:"Petrol",rating:4.8,image:"assets/cars/bmw-3-series.png",demand:"normal"},
{id:7,brand:"Maruti",model:"Alto K10",type:"Hatchback",price:799,seats:5,trans:"Manual",fuel:"Petrol",rating:4.5,image:"assets/cars/alto-k10.png",demand:"normal"},
{id:8,brand:"Renault",model:"Kwid",type:"Hatchback",price:899,seats:5,trans:"Manual",fuel:"Petrol",rating:4.5,image:"assets/cars/kwid.png",demand:"low"},
{id:9,brand:"Tata",model:"Tiago",type:"Hatchback",price:999,seats:5,trans:"Manual",fuel:"Petrol",rating:4.6,image:"assets/cars/tiago.png",demand:"normal"},
{id:10,brand:"Hyundai",model:"Grand i10",type:"Hatchback",price:1099,seats:5,trans:"Manual",fuel:"Petrol",rating:4.6,image:"assets/cars/grand-i10.png",demand:"low"}
];

const COUPONS={DRIVE10:{pct:10,label:"10% off your rental"},WELCOME20:{pct:20,label:"20% off — first ride"},STUDENT15:{pct:15,label:"15% student discount"}};
const ADMIN_EMAIL="admin@driveease.com", ADMIN_PASS="admin123";

/* ---------- 2. Storage helpers ---------- */
function dbGet(key,fallback){try{const v=localStorage.getItem(key);return v===null?fallback:JSON.parse(v)}catch(e){return fallback}}
function dbSet(key,val){localStorage.setItem(key,JSON.stringify(val))}
function uid(prefix){return prefix+"-"+Math.random().toString(36).slice(2,8).toUpperCase()}
function money(n){return "₹"+Number(n||0).toLocaleString("en-IN")}
function daysBetween(a,b){const d1=new Date(a),d2=new Date(b);const diff=Math.round((d2-d1)/86400000)+1;return diff>0?diff:1}
function fmtDate(s){if(!s)return "—";const d=new Date(s);return d.toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"})}

/* ---------- 3. Vehicles (admin-editable fleet) ---------- */
function getVehicles(){let v=dbGet("de_vehicles",null);if(!v){v=DEFAULT_CARS.slice();dbSet("de_vehicles",v)}return v}
function saveVehicles(list){dbSet("de_vehicles",list)}
function getVehicle(id){return getVehicles().find(c=>c.id===Number(id))}
function addVehicle(v){const list=getVehicles();const nextId=list.length?Math.max(...list.map(c=>c.id))+1:1;v.id=nextId;v.rating=v.rating||4.5;v.demand=v.demand||"normal";list.push(v);saveVehicles(list);return v}
function deleteVehicle(id){saveVehicles(getVehicles().filter(c=>c.id!==Number(id)))}

/* ---------- 4. Auth ---------- */
function getUsers(){return dbGet("de_users",[])}
function saveUsers(list){dbSet("de_users",list)}
function getSession(){return dbGet("de_session",null)}
function setSession(email){dbSet("de_session",{email})}
function clearSession(){localStorage.removeItem("de_session")}
function currentUser(){const s=getSession();if(!s)return null;return getUsers().find(u=>u.email===s.email)||null}
function isAdminSession(){const s=getSession();return !!s&&s.email===ADMIN_EMAIL}

function registerUser(data){
  const name=data.name,email=data.email,password=data.password,phone=data.phone;
  const users=getUsers();
  if(users.some(u=>u.email===email)) return {ok:false,error:"An account with this email already exists."};
  const user={id:uid("USR"),name:name,email:email,password:password,phone:phone||"",points:20,tier:"Bronze",joined:new Date().toISOString()};
  users.push(user);saveUsers(users);setSession(email);
  addNotification("Welcome to DriveEase 👋","Hi "+name.split(" ")[0]+", your account is ready. You've earned 20 welcome points.");
  return {ok:true,user:user};
}
function loginUser(email,password){
  if(email===ADMIN_EMAIL&&password===ADMIN_PASS){setSession(email);return {ok:true,admin:true}}
  const user=getUsers().find(u=>u.email===email&&u.password===password);
  if(!user) return {ok:false,error:"Email or password is incorrect."};
  setSession(email);return {ok:true,user:user};
}
function logoutUser(){clearSession();location.href="index.html"}

/* ---------- 5. Wishlist (per user, falls back to guest) ---------- */
function wishlistKey(){const u=currentUser();return "de_wishlist_"+(u?u.email:"guest")}
function getWishlist(){return dbGet(wishlistKey(),[])}
function wishlist(id){
  id=Number(id);const c=getVehicle(id);let w=getWishlist();
  const has=w.includes(id);
  w=has?w.filter(x=>x!==id):w.concat([id]);
  dbSet(wishlistKey(),w);
  showToast(has?(c.brand+" "+c.model+" removed from favourites"):(c.brand+" "+c.model+" added to favourites ♥"));
  document.querySelectorAll('[data-heart="'+id+'"]').forEach(btn=>btn.classList.toggle("active",!has));
  const counter=document.getElementById("favCount");if(counter)counter.textContent=getWishlist().length;
  return !has;
}

/* ---------- 6. Reviews & ratings ---------- */
function getReviews(carId){return dbGet("de_reviews",[]).filter(r=>r.carId===Number(carId)).sort((a,b)=>new Date(b.date)-new Date(a.date))}
function addReview(carId,name,rating,comment){
  const all=dbGet("de_reviews",[]);
  all.push({id:uid("REV"),carId:Number(carId),name:name||"Guest",rating:Number(rating),comment:comment,date:new Date().toISOString()});
  dbSet("de_reviews",all);
}
function avgRating(carId){
  const revs=getReviews(carId);const v=getVehicle(carId);const base=v?v.rating:4.5;
  if(!revs.length)return base;
  const sum=revs.reduce((a,r)=>a+r.rating,0)+base*8; // blend seed rating so it doesn't swing wildly on 1 review
  return Math.round((sum/(revs.length+8))*10)/10;
}

/* ---------- 7. Notifications ---------- */
function notifKey(){const u=currentUser();return "de_notifs_"+(u?u.email:"guest")}
function getNotifications(){return dbGet(notifKey(),[]).sort((a,b)=>new Date(b.date)-new Date(a.date))}
function addNotification(title,msg){
  const list=dbGet(notifKey(),[]);
  list.push({id:uid("NTF"),title:title,msg:msg,date:new Date().toISOString(),read:false});
  dbSet(notifKey(),list);
  renderNotifBadge();
}
function markAllRead(){const list=dbGet(notifKey(),[]).map(n=>Object.assign({},n,{read:true}));dbSet(notifKey(),list);renderNotifBadge()}
function unreadCount(){return dbGet(notifKey(),[]).filter(n=>!n.read).length}

/* ---------- 8. Bookings ---------- */
function getAllBookings(){return dbGet("de_bookings",[])}
function saveAllBookings(list){dbSet("de_bookings",list)}
function getMyBookings(){
  const u=currentUser();
  const all=getAllBookings();
  const list = u ? all.filter(b=>b.userEmail===u.email) : all.filter(b=>b.userEmail==="guest");
  return list.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
}
function bookingStatus(b){
  if(b.status==="Cancelled")return "Cancelled";
  const today=new Date().setHours(0,0,0,0);
  const start=new Date(b.date).setHours(0,0,0,0), end=new Date(b.returnDate).setHours(0,0,0,0);
  if(today<start)return "Upcoming";
  if(today>=start&&today<=end)return "Ongoing";
  return "Completed";
}
function createBooking(data){
  const u=currentUser();
  const days=daysBetween(data.date,data.returnDate);
  const car=getVehicle(data.carId);
  const surge=car.demand==="high"?1.12:1;
  const subtotal=Math.round(car.price*days*surge);
  const coupon=data.couponCode&&COUPONS[data.couponCode.toUpperCase()];
  const discount=coupon?Math.round(subtotal*coupon.pct/100):0;
  const total=subtotal-discount;
  const booking={
    id:uid("DE"),userEmail:u?u.email:"guest",carId:car.id,carSnapshot:car,
    name:data.name,pickup:data.pickup,date:data.date,returnDate:data.returnDate,days:days,
    notes:data.notes||"",docUploaded:!!data.docUploaded,
    rate:car.price,subtotal:subtotal,couponCode:coupon?data.couponCode.toUpperCase():null,discount:discount,total:total,
    status:"Confirmed",createdAt:new Date().toISOString()
  };
  const all=getAllBookings();all.push(booking);saveAllBookings(all);
  dbSet("pendingBooking",null);
  return booking;
}
function cancelBooking(id){
  const all=getAllBookings().map(b=>b.id===id?Object.assign({},b,{status:"Cancelled"}):b);
  saveAllBookings(all);
  addNotification("Booking cancelled","Your booking "+id+" has been cancelled. Refunds (demo) are instant.");
}
function totalRevenue(){return getAllBookings().filter(b=>b.status!=="Cancelled").reduce((a,b)=>a+b.total,0)}

/* ---------- Loyalty tiers ---------- */
function tierFor(points){
  if(points>=500)return {name:"Platinum",color:"#c9d6ff",next:null};
  if(points>=250)return {name:"Gold",color:"#ffd76a",next:500};
  if(points>=100)return {name:"Silver",color:"#c9d3de",next:250};
  return {name:"Bronze",color:"#e2a76f",next:100};
}
function addPoints(email,pts){
  const users=getUsers().map(u=>u.email===email?Object.assign({},u,{points:(u.points||0)+pts}):u);
  saveUsers(users);
}

/* ---------- 9. Theme ---------- */
function initTheme(){const t=dbGet("de_theme","dark");document.documentElement.setAttribute("data-theme",t)}
function toggleTheme(){
  const cur=document.documentElement.getAttribute("data-theme")||"dark";
  const next=cur==="dark"?"light":"dark";
  document.documentElement.setAttribute("data-theme",next);dbSet("de_theme",next);
  const btn=document.getElementById("themeToggle");if(btn)btn.textContent=next==="dark"?"☀️":"🌙";
}

/* ---------- 10. Toast ---------- */
function showToast(msg){
  let t=document.getElementById("toast");
  if(!t){t=document.createElement("div");t.id="toast";t.className="toast";document.body.appendChild(t)}
  t.textContent=msg;t.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer=setTimeout(()=>t.classList.remove("show"),2600);
}

/* ---------- 10.5 App shell: back button + bottom tab bar (mobile) ---------- */
const APP_STACK_PAGES=["login.html","register.html","car-details.html","booking.html","payment.html","confirmation.html","self-service.html","admin.html"];
function currentPageName(){
  const p=location.pathname.split("/").pop();
  return p||"index.html";
}
function renderAppShell(){
  const page=currentPageName();
  const nav=document.querySelector(".navbar");
  if(!nav)return;

  if(APP_STACK_PAGES.indexOf(page)!==-1){
    if(!nav.querySelector(".back-btn")){
      const back=document.createElement("a");
      back.href="#";
      back.className="back-btn";
      back.setAttribute("aria-label","Back");
      back.innerHTML="←";
      back.addEventListener("click",(e)=>{
        e.preventDefault();
        if(history.length>1)history.back();else location.href="index.html";
      });
      nav.insertBefore(back,nav.firstChild);
    }
    return;
  }

  if(!document.getElementById("appTabbar")){
    const u=currentUser();
    const isAdmin=isAdminSession();
    const profileHref=(u||isAdmin)?"profile.html":"login.html";
    const tabs=[
      {href:"index.html",icon:"🏠",label:"Home"},
      {href:"cars.html",icon:"🚗",label:"Cars"},
      {href:"bookings.html",icon:"🧾",label:"Trips"},
      {href:"favorites.html",icon:"♥",label:"Saved"},
      {href:profileHref,icon:"👤",label:"Profile"}
    ];
    const bar=document.createElement("nav");
    bar.id="appTabbar";
    bar.className="app-tabbar";
    bar.innerHTML=tabs.map(t=>
      '<a href="'+t.href+'" class="'+(t.href===page?"active":"")+'"><span class="tab-ic">'+t.icon+'</span>'+t.label+'</a>'
    ).join("");
    document.body.appendChild(bar);
    document.body.classList.add("has-tabbar");
  }
}

/* ---------- 11. Global UI injection (runs on every page) ---------- */
function renderNotifBadge(){
  const dot=document.getElementById("notifDot");
  if(dot)dot.style.display=unreadCount()>0?"block":"none";
}
function buildNotifDropdown(){
  const items=getNotifications();
  const body=items.length?items.map(n=>'<div class="notif-item '+(n.read?"":"unread")+'"><b>'+n.title+'</b><p>'+n.msg+'</p><span>'+fmtDate(n.date)+'</span></div>').join(""):
    '<div class="notif-empty">No notifications yet.<br>Book a ride to see updates here.</div>';
  return '<div class="notif-head"><span>Notifications</span><button id="markReadBtn">Mark all read</button></div><div class="notif-list">'+body+'</div>';
}
function wireNotifMarkRead(){
  document.getElementById("markReadBtn")?.addEventListener("click",()=>{
    markAllRead();
    const dd=document.getElementById("notifDropdown");
    if(dd){dd.innerHTML=buildNotifDropdown();wireNotifMarkRead()}
  });
}
function initGlobalUI(){
  initTheme();
  const nav=document.querySelector(".navbar");
  if(!nav)return;

  // avoid double-injection
  if(nav.querySelector(".nav-utility"))return;

  const util=document.createElement("div");
  util.className="nav-utility";

  const u=currentUser();
  const isAdmin=isAdminSession();
  const loggedInName=isAdmin?"Admin":(u?u.name.split(" ")[0]:"");
  const avatarLetter=isAdmin?"A":(u&&u.name?u.name[0].toUpperCase():"U");

  util.innerHTML=
    '<button class="icon-btn" id="themeToggle" title="Toggle theme">'+((dbGet("de_theme","dark")==="dark")?"☀️":"🌙")+'</button>'+
    '<a class="icon-btn" href="favorites.html" title="Favourites">♥<span id="favCount" class="mini-count">'+getWishlist().length+'</span></a>'+
    '<div class="notif-wrap">'+
      '<button class="icon-btn" id="notifBtn" title="Notifications">🔔<span id="notifDot" class="notif-dot"></span></button>'+
      '<div class="notif-dropdown" id="notifDropdown">'+buildNotifDropdown()+'</div>'+
    '</div>'+
    ( (u||isAdmin) ?
      '<div class="user-wrap"><button class="user-chip" id="userChip"><span class="user-avatar">'+avatarLetter+'</span>'+loggedInName+'</button>'+
      '<div class="user-dropdown" id="userDropdown">'+
        (isAdmin?'<a href="admin.html">Admin dashboard</a>':'<a href="profile.html">Profile</a><a href="bookings.html">My bookings</a><a href="favorites.html">Favourites</a>')+
        '<button id="logoutBtn">Log out</button></div></div>'
      : '<a class="btn btn-outline" href="login.html">Login</a>' );

  // Replace any existing static login button with our utility bar
  const staticLogin=nav.querySelector('a.btn-outline[href="login.html"]');
  if(staticLogin) staticLogin.remove();
  nav.appendChild(util);

  document.getElementById("themeToggle")?.addEventListener("click",toggleTheme);
  document.getElementById("logoutBtn")?.addEventListener("click",logoutUser);

  const notifBtn=document.getElementById("notifBtn"),notifDD=document.getElementById("notifDropdown");
  notifBtn?.addEventListener("click",(e)=>{e.stopPropagation();notifDD.classList.toggle("open");document.getElementById("userDropdown")?.classList.remove("open")});
  wireNotifMarkRead();

  const userChip=document.getElementById("userChip"),userDD=document.getElementById("userDropdown");
  userChip?.addEventListener("click",(e)=>{e.stopPropagation();userDD.classList.toggle("open");notifDD?.classList.remove("open")});

  document.addEventListener("click",()=>{notifDD?.classList.remove("open");userDD?.classList.remove("open")});
  renderNotifBadge();
  renderAppShell();
}

/* ---------- 12. Recommendations ---------- */
function recommendCars(limit){
  limit=limit||3;
  const vehicles=getVehicles();
  const w=getWishlist();
  let favTypes=w.map(id=>{const v=getVehicle(id);return v?v.type:null}).filter(Boolean);
  const bookedTypes=getMyBookings().map(b=>b.carSnapshot?b.carSnapshot.type:null).filter(Boolean);
  favTypes=favTypes.concat(bookedTypes);
  let pool;
  if(favTypes.length){
    const topType=favTypes.sort((a,b)=>favTypes.filter(t=>t===a).length-favTypes.filter(t=>t===b).length).pop();
    pool=vehicles.filter(c=>c.type===topType && w.indexOf(c.id)===-1);
    if(pool.length<limit) pool=pool.concat(vehicles.filter(c=>pool.indexOf(c)===-1));
  } else {
    pool=vehicles.slice().sort((a,b)=>b.rating-a.rating);
  }
  return pool.slice(0,limit);
}

/* ---------- 13. Compare ---------- */
function getCompare(){return dbGet("de_compare",[])}
function toggleCompare(id){
  id=Number(id);let c=getCompare();
  if(c.indexOf(id)!==-1) c=c.filter(x=>x!==id);
  else { if(c.length>=3){showToast("You can compare up to 3 cars at a time");return renderCompareBar()} c.push(id) }
  dbSet("de_compare",c);renderCompareBar();
  document.querySelectorAll('[data-compare="'+id+'"]').forEach(el=>el.classList.toggle("active",c.indexOf(id)!==-1));
}
function renderCompareBar(){
  const bar=document.getElementById("compareBar");if(!bar)return;
  const list=getCompare();
  if(!list.length){bar.classList.remove("show");return}
  bar.classList.add("show");
  bar.innerHTML='<span>'+list.length+' car'+(list.length>1?"s":"")+' selected</span>'+
    '<div class="compare-thumbs">'+list.map(id=>{const c=getVehicle(id);return c?('<span class="compare-chip">'+c.brand+' '+c.model+' <b data-x="'+id+'">×</b></span>'):""}).join("")+'</div>'+
    '<button class="btn btn-primary" id="compareGo" '+(list.length<2?"disabled":"")+'>Compare</button>'+
    '<button class="btn btn-outline" id="compareClear">Clear</button>';
  bar.querySelectorAll("[data-x]").forEach(el=>el.addEventListener("click",()=>toggleCompare(el.dataset.x)));
  document.getElementById("compareClear").addEventListener("click",()=>{dbSet("de_compare",[]);document.querySelectorAll("[data-compare]").forEach(el=>el.classList.remove("active"));renderCompareBar()});
  document.getElementById("compareGo").addEventListener("click",openCompareModal);
}
function openCompareModal(){
  const list=getCompare().map(getVehicle).filter(Boolean);
  if(list.length<2)return;
  const rows=[
    ["Price / day",function(c){return money(c.price)}],
    ["Type",function(c){return c.type}],
    ["Seats",function(c){return c.seats}],
    ["Transmission",function(c){return c.trans}],
    ["Fuel",function(c){return c.fuel}],
    ["Rating",function(c){return "⭐ "+avgRating(c.id)}],
    ["Demand",function(c){return c.demand}]
  ];
  const modal=document.createElement("div");
  modal.className="modal-overlay";
  modal.innerHTML='<div class="modal-card compare-modal">'+
    '<div class="modal-head"><h2>Compare cars</h2><button class="modal-close">×</button></div>'+
    '<div class="compare-grid" style="grid-template-columns:140px repeat('+list.length+',1fr)">'+
      '<div></div>'+list.map(c=>'<div class="compare-col-head"><img src="'+c.image+'"><b>'+c.brand+' '+c.model+'</b></div>').join("")+
      rows.map(function(row){return '<div class="compare-label">'+row[0]+'</div>'+list.map(function(c){return '<div>'+row[1](c)+'</div>'}).join("")}).join("")+
      '<div></div>'+list.map(c=>'<div><a class="btn btn-primary full" href="booking.html?id='+c.id+'">Book this</a></div>').join("")+
    '</div></div>';
  document.body.appendChild(modal);
  modal.querySelector(".modal-close").addEventListener("click",()=>modal.remove());
  modal.addEventListener("click",e=>{if(e.target===modal)modal.remove()});
}

/* ---------- 14. Card + list renderers ---------- */
function ratingStars(r){const full=Math.round(r);return "★".repeat(full)+"☆".repeat(5-full)}
function carCard(c){
  const w=getWishlist().indexOf(c.id)!==-1;
  const cmp=getCompare().indexOf(c.id)!==-1;
  const rating=avgRating(c.id);
  const demandBadge=c.demand==="high"?'<span class="demand-badge high">🔥 High demand</span>':(c.demand==="low"?'<span class="demand-badge low">Great value</span>':"");
  return '<article class="car-card">'+
    '<div class="car-img"><img src="'+c.image+'" alt="'+c.brand+' '+c.model+'" loading="lazy">'+demandBadge+'</div>'+
    '<div class="car-info">'+
      '<div class="car-top"><h3>'+c.brand+' '+c.model+'</h3><span class="tag">'+c.type+'</span></div>'+
      '<div class="rating-line" title="'+getReviews(c.id).length+' reviews">'+ratingStars(rating)+' <b>'+rating+'</b></div>'+
      '<div class="specs"><span>👥 '+c.seats+'</span><span>⚙ '+c.trans+'</span><span>⛽ '+c.fuel+'</span></div>'+
      '<div class="card-actions">'+
        '<div class="price">'+money(c.price)+' <small>/ day</small></div>'+
        '<div style="display:flex;gap:7px;align-items:center">'+
          '<button class="btn btn-outline heart-btn '+(w?"active":"")+'" data-heart="'+c.id+'" style="padding:9px 11px" onclick="wishlist('+c.id+')">♡</button>'+
          '<a class="btn btn-primary" href="car-details.html?id='+c.id+'">View</a>'+
        '</div>'+
      '</div>'+
      '<label class="compare-check"><input type="checkbox" data-compare="'+c.id+'" '+(cmp?"checked":"")+' onchange="toggleCompare('+c.id+')"> Compare</label>'+
    '</div>'+
  '</article>';
}
function renderCars(target,limit){
  const el=document.getElementById(target);if(!el)return;
  const vehicles=getVehicles();
  let data=limit?vehicles.slice(0,limit):vehicles;
  const draw=()=>{
    let s=document.getElementById("carSearch")?.value.toLowerCase()||"",
        t=document.getElementById("typeFilter")?.value||"all",
        b=document.getElementById("budgetFilter")?.value||"all",
        sort=document.getElementById("sortCars")?.value||"default";
    let d=data.filter(c=>(c.brand+" "+c.model).toLowerCase().indexOf(s)!==-1&&(t==="all"||c.type===t)&&(b==="all"||(b==="budget"&&c.price<1200)||(b==="mid"&&c.price>=1200&&c.price<=2500)||(b==="premium"&&c.price>2500)));
    if(sort==="low")d.sort((a,b)=>a.price-b.price);
    if(sort==="high")d.sort((a,b)=>b.price-a.price);
    if(sort==="rating")d.sort((a,b)=>avgRating(b.id)-avgRating(a.id));
    el.innerHTML=d.map(carCard).join("")||'<div class="empty-state"><h3>No cars match your filters</h3><p>Try widening your search or clearing a filter.</p></div>';
  };
  draw();
  ["carSearch","typeFilter","budgetFilter","sortCars"].forEach(id=>document.getElementById(id)?.addEventListener("input",draw));
  const loc=new URLSearchParams(location.search).get("loc");
  const bannerLoc=document.getElementById("locBanner");
  if(loc&&bannerLoc)bannerLoc.textContent="Showing cars near "+loc;
  renderCompareBar();
}

/* ---------- 15. Car details (with reviews + recommendations) ---------- */
const qs=new URLSearchParams(location.search);
const selectedId=Number(qs.get("id"))||1;
function getSelected(){return getVehicle(selectedId)||getVehicles()[0]}

function renderDetails(){
  const c=getSelected();
  const rating=avgRating(c.id);
  const reviews=getReviews(c.id);
  const w=getWishlist().indexOf(c.id)!==-1;
  document.getElementById("details").innerHTML=
  '<div class="detail-layout">'+
    '<div class="detail-image"><img src="'+c.image+'" alt="'+c.brand+' '+c.model+'">'+(c.demand==="high"?'<span class="demand-badge high" style="position:absolute;top:16px;left:16px">🔥 High demand — book soon</span>':"")+'</div>'+
    '<section class="detail">'+
      '<p class="eyebrow">'+c.type.toUpperCase()+'</p>'+
      '<h1>'+c.brand+' '+c.model+'</h1>'+
      '<div class="rating-line">'+ratingStars(rating)+' <b>'+rating+'</b> <span class="muted">('+reviews.length+' review'+(reviews.length===1?"":"s")+')</span></div>'+
      '<div class="feature-grid">'+
        '<div class="feature">👥 '+c.seats+' Seats</div>'+
        '<div class="feature">⚙ '+c.trans+'</div>'+
        '<div class="feature">⛽ '+c.fuel+'</div>'+
        '<div class="feature">📍 Multiple pickup points</div>'+
      '</div>'+
      '<h2>'+money(c.price)+' <small>/ day</small></h2>'+
      '<p>Includes basic rental support and digital self-service pickup.</p>'+
      '<div style="display:flex;gap:10px">'+
        '<a class="btn btn-primary" href="booking.html?id='+c.id+'">Book this car →</a>'+
        '<button class="btn btn-outline heart-btn '+(w?"active":"")+'" data-heart="'+c.id+'" onclick="wishlist('+c.id+')">♡ Save</button>'+
      '</div>'+
    '</section>'+
  '</div>'+

  '<section class="reviews-section">'+
    '<h2>Reviews</h2>'+
    '<div class="review-form panel">'+
      '<h3>Rate this car</h3>'+
      '<div class="star-input" id="starInput">'+[1,2,3,4,5].map(n=>'<span data-star="'+n+'">★</span>').join("")+'</div>'+
      '<input id="reviewName" placeholder="'+(currentUser()?currentUser().name:"Your name")+'">'+
      '<textarea id="reviewText" placeholder="How was your ride?"></textarea>'+
      '<button class="btn btn-primary" id="submitReview">Post review</button>'+
    '</div>'+
    '<div class="review-list" id="reviewList">'+(reviews.length?reviews.map(r=>'<div class="review-item"><div class="review-top"><b>'+r.name+'</b><span>'+ratingStars(r.rating)+'</span></div><p>'+r.comment+'</p><span class="muted">'+fmtDate(r.date)+'</span></div>').join(""):'<p class="muted">No reviews yet — be the first to share your experience.</p>')+'</div>'+
  '</section>'+

  '<section class="section" style="padding-top:0">'+
    '<div class="section-heading"><div><p class="eyebrow">YOU MIGHT ALSO LIKE</p><h2>Similar cars</h2></div></div>'+
    '<div id="similarCars" class="car-grid"></div>'+
  '</section>';

  let selStars=0;
  document.querySelectorAll("#starInput span").forEach(s=>s.addEventListener("click",()=>{
    selStars=Number(s.dataset.star);
    document.querySelectorAll("#starInput span").forEach(x=>x.classList.toggle("active",Number(x.dataset.star)<=selStars));
  }));
  document.getElementById("submitReview").addEventListener("click",()=>{
    if(!selStars){showToast("Please select a star rating");return}
    const name=document.getElementById("reviewName").value||(currentUser()?currentUser().name:"Guest");
    const text=document.getElementById("reviewText").value||"Great experience!";
    addReview(c.id,name,selStars,text);
    showToast("Thanks for your review!");
    renderDetails();
  });

  const similar=getVehicles().filter(x=>x.type===c.type&&x.id!==c.id).slice(0,3);
  const similarFinal = similar.length?similar:getVehicles().filter(x=>x.id!==c.id).slice(0,3);
  document.getElementById("similarCars").innerHTML=similarFinal.map(carCard).join("");
}

/* ---------- 16. Booking (with day-based pricing + doc upload) ---------- */
function renderBooking(){
  const c=getSelected();
  const surge=c.demand==="high";
  document.getElementById("bookingSummary").innerHTML=
    '<p class="eyebrow">YOUR CAR</p>'+
    '<h2>'+c.brand+' '+c.model+'</h2>'+
    '<img src="'+c.image+'" style="width:100%;height:180px;object-fit:cover;border-radius:14px" alt="'+c.brand+' '+c.model+'">'+
    (surge?'<p class="demand-note">🔥 High demand — a small peak-time rate applies.</p>':"")+
    '<div class="summary-row"><span>Rate</span><b>'+money(c.price)+'/day</b></div>'+
    '<div class="summary-row"><span>Duration</span><b id="sumDays">1 day</b></div>'+
    '<div class="summary-row total"><span>Estimated total</span><b id="sumTotal">'+money(c.price)+'</b></div>'+
    '<p class="muted" style="font-size:12px">Final total (with taxes & discounts) is confirmed on the payment step.</p>';

  const d1=document.getElementById("bd1"),d2=document.getElementById("bd2");
  const updateTotal=()=>{
    if(d1.value&&d2.value){
      const days=daysBetween(d1.value,d2.value);
      document.getElementById("sumDays").textContent=days+" day"+(days>1?"s":"");
      document.getElementById("sumTotal").textContent=money(c.price*days*(surge?1.12:1));
    }
  };
  d1?.addEventListener("change",updateTotal);d2?.addEventListener("change",updateTotal);

  const u=currentUser();
  if(u)document.getElementById("name").value=u.name;

  document.getElementById("bookingForm").addEventListener("submit",e=>{
    e.preventDefault();
    const docFile=document.getElementById("license")?.files?.[0];
    if(!docFile){showToast("Please upload your driving licence to continue");return}
    dbSet("pendingBooking",{
      carId:c.id,name:document.getElementById("name").value,pickup:document.getElementById("pickup").value,
      date:d1.value,returnDate:d2.value,notes:document.getElementById("notes").value,docUploaded:true
    });
    location.href="payment.html";
  });
}

/* ---------- 17. Payment (with coupons) ---------- */
function renderPayment(){
  const pending=dbGet("pendingBooking",null);
  if(!pending){location.href="cars.html";return}
  const c=getVehicle(pending.carId);
  const surge=c.demand==="high"?1.12:1;
  const days=daysBetween(pending.date,pending.returnDate);
  const subtotal=Math.round(c.price*days*surge);
  let discount=0,appliedCode=null;

  const renderSummary=()=>{
    document.getElementById("paymentSummary").innerHTML=
      '<p class="eyebrow">ORDER SUMMARY</p>'+
      '<img src="'+c.image+'" style="width:100%;height:160px;object-fit:cover;border-radius:14px" alt="'+c.brand+' '+c.model+'">'+
      '<h2>'+c.brand+' '+c.model+'</h2>'+
      '<div class="summary-row"><span>'+days+' day'+(days>1?"s":"")+' × '+money(c.price)+'</span><b>'+money(subtotal)+'</b></div>'+
      (discount?'<div class="summary-row" style="color:var(--success)"><span>Coupon '+appliedCode+'</span><b>−'+money(discount)+'</b></div>':"")+
      '<div class="summary-row"><span>Taxes</span><b>Included</b></div>'+
      '<div class="summary-row total"><span>Total</span><b>'+money(subtotal-discount)+'</b></div>';
  };
  renderSummary();

  document.getElementById("applyCoupon")?.addEventListener("click",()=>{
    const code=(document.getElementById("couponInput").value||"").toUpperCase().trim();
    const coupon=COUPONS[code];
    const msg=document.getElementById("couponMsg");
    if(!coupon){msg.textContent="Invalid or expired code.";msg.className="coupon-msg bad";discount=0;appliedCode=null}
    else{discount=Math.round(subtotal*coupon.pct/100);appliedCode=code;msg.textContent="Applied! "+coupon.label+".";msg.className="coupon-msg good"}
    renderSummary();
  });

  document.getElementById("paymentForm").addEventListener("submit",e=>{
    e.preventDefault();
    const bookingData=Object.assign({},pending,{couponCode:appliedCode});
    const booking=createBooking(bookingData);
    const u=currentUser();
    if(u){const pts=Math.round(booking.total/100);addPoints(u.email,pts);addNotification("Booking confirmed 🎉",c.brand+" "+c.model+" is booked. You earned "+pts+" loyalty points.")}
    else addNotification("Booking confirmed 🎉",c.brand+" "+c.model+" is booked. Booking ID "+booking.id+".");
    dbSet("lastBooking",booking.id);
    location.href="confirmation.html";
  });
}

/* ---------- 18. Confirmation ---------- */
function renderConfirmation(){
  const id=dbGet("lastBooking",null);
  const b=getAllBookings().find(x=>x.id===id);
  if(!b)return;
  document.getElementById("confirmation").innerHTML=
    '<p><b>Booking ID:</b> '+b.id+'</p>'+
    '<p><b>'+b.carSnapshot.brand+' '+b.carSnapshot.model+'</b><br>'+(b.pickup||"Pickup location")+' · '+fmtDate(b.date)+' → '+fmtDate(b.returnDate)+' ('+b.days+' day'+(b.days>1?"s":"")+')</p>'+
    (b.discount?'<p>Coupon '+b.couponCode+' applied · saved '+money(b.discount)+'</p>':"")+
    '<p><b>Total paid: '+money(b.total)+'</b></p>';
}

/* ---------- 19. My bookings (multi + cancel) ---------- */
function renderBookings(){
  const list=getMyBookings();
  const el=document.getElementById("bookings");
  if(!list.length){el.innerHTML='<div class="panel empty-state"><h2>No bookings yet</h2><p>Choose a car to start your first trip.</p><a class="btn btn-primary" href="cars.html">Browse cars</a></div>';return}
  el.innerHTML=list.map(b=>{
    const status=bookingStatus(b);
    const statusClass=status==="Cancelled"?"status-cancel":(status==="Completed"?"status-done":(status==="Ongoing"?"status-live":"status"));
    return '<div class="booking-item">'+
      '<img src="'+b.carSnapshot.image+'" alt="'+b.carSnapshot.brand+'">'+
      '<div class="booking-mid"><h3>'+b.carSnapshot.brand+' '+b.carSnapshot.model+'</h3>'+
        '<p>'+(b.pickup||"Pickup location")+' · '+fmtDate(b.date)+' → '+fmtDate(b.returnDate)+'</p>'+
        '<p><b>Booking '+b.id+'</b> · '+money(b.total)+'</p></div>'+
      '<div class="booking-actions"><span class="'+statusClass+'">'+status+'</span>'+
        (status==="Upcoming"?'<button class="btn btn-outline" style="margin-top:10px" onclick="cancelBooking(\''+b.id+'\');renderBookings()">Cancel</button>':"")+
        (status!=="Cancelled"?'<a class="btn btn-primary" style="margin-top:10px" href="self-service.html?bid='+b.id+'">Self-service</a>':"")+
      '</div>'+
    '</div>';
  }).join("");
}

/* ---------- 20. Self-service + live tracking ---------- */
function renderSelfService(){
  const bid=new URLSearchParams(location.search).get("bid");
  const mine=getMyBookings();
  const b=(bid&&getAllBookings().find(x=>x.id===bid))||mine[0];
  const passIdEl=document.getElementById("passId");
  if(!b){if(passIdEl)passIdEl.textContent="Booking #DE-4829";return}
  if(passIdEl)passIdEl.textContent="Booking #"+b.id;
  const carEl=document.getElementById("passCar");
  if(carEl)carEl.textContent=b.carSnapshot.brand+" "+b.carSnapshot.model;

  // live tracking simulation
  const eta=document.getElementById("etaValue");
  if(!eta)return;
  let seconds=180+Math.floor(Math.random()*300);
  const timer=setInterval(()=>{
    if(seconds<=0){eta.textContent="Arrived";clearInterval(timer);return}
    seconds-=1;const m=Math.floor(seconds/60),s=seconds%60;
    eta.textContent=m+"m "+String(s).padStart(2,"0")+"s";
  },1000);
  const m0=Math.floor(seconds/60),s0=seconds%60;
  eta.textContent=m0+"m "+String(s0).padStart(2,"0")+"s";
}

/* ---------- 21. Profile & loyalty ---------- */
function renderProfile(){
  const u=currentUser();
  const wrap=document.getElementById("profileRoot");
  if(!u){wrap.innerHTML='<div class="panel empty-state"><h2>You\'re not logged in</h2><p>Log in to view your profile and loyalty status.</p><a class="btn btn-primary" href="login.html">Login</a></div>';return}
  const tier=tierFor(u.points);
  const bookings=getMyBookings().filter(b=>b.status!=="Cancelled");
  const pct=tier.next?Math.min(100,(u.points/tier.next)*100):100;
  wrap.innerHTML=
  '<section class="panel profile-card">'+
    '<div class="avatar">'+u.name[0].toUpperCase()+'</div>'+
    '<h2>'+u.name+'</h2><p>'+u.email+'</p>'+
    '<span class="tier-badge" style="background:'+tier.color+'22;color:'+tier.color+';border-color:'+tier.color+'55">'+tier.name+' member</span>'+
    '<div class="loyalty-bar"><div class="loyalty-fill" style="width:'+pct+'%"></div></div>'+
    '<p class="muted" style="font-size:12px">'+(tier.next?(u.points+" / "+tier.next+" pts to next tier"):"Top tier reached")+'</p>'+
    '<div class="profile-stats"><div><b>'+bookings.length+'</b><span>Trips</span></div><div><b>'+u.points+'</b><span>Points</span></div><div><b>'+getWishlist().length+'</b><span>Saved</span></div></div>'+
  '</section>'+
  '<section class="panel">'+
    '<label>Full name<input id="pfName" value="'+u.name+'"></label>'+
    '<label>Email<input value="'+u.email+'" disabled></label>'+
    '<label>Mobile<input id="pfPhone" value="'+(u.phone||"")+'"></label>'+
    '<button class="btn btn-primary" id="pfSave">Save changes</button>'+
  '</section>';
  document.getElementById("pfSave").addEventListener("click",()=>{
    const users=getUsers().map(x=>x.email===u.email?Object.assign({},x,{name:document.getElementById("pfName").value,phone:document.getElementById("pfPhone").value}):x);
    saveUsers(users);showToast("Profile saved");
  });
}

/* ---------- 22. Favourites page ---------- */
function renderFavorites(){
  const el=document.getElementById("favGrid");
  const ids=getWishlist();
  const list=ids.map(getVehicle).filter(Boolean);
  el.innerHTML=list.length?list.map(carCard).join(""):'<div class="empty-state panel"><h2>No favourites yet</h2><p>Tap the heart on any car to save it here.</p><a class="btn btn-primary" href="cars.html">Browse cars</a></div>';
}

/* ---------- 23. Auth pages ---------- */
function wireLogin(){
  document.getElementById("loginForm").addEventListener("submit",e=>{
    e.preventDefault();
    const email=document.getElementById("loginEmail").value.trim(),pass=document.getElementById("loginPassword").value;
    const res=loginUser(email,pass);
    const err=document.getElementById("loginError");
    if(!res.ok){err.textContent=res.error;err.style.display="block";return}
    location.href=res.admin?"admin.html":"index.html";
  });
}
function wireRegister(){
  document.getElementById("registerForm").addEventListener("submit",e=>{
    e.preventDefault();
    const name=document.getElementById("regName").value.trim(),email=document.getElementById("regEmail").value.trim(),
          password=document.getElementById("regPassword").value,phone=document.getElementById("regPhone").value.trim();
    const res=registerUser({name:name,email:email,password:password,phone:phone});
    const err=document.getElementById("registerError");
    if(!res.ok){err.textContent=res.error;err.style.display="block";return}
    location.href="index.html";
  });
}

/* ---------- 24. Admin dashboard ---------- */
function requireAdmin(){if(!isAdminSession()){location.href="login.html"}}
function renderAdmin(){
  requireAdmin();
  const bookings=getAllBookings().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  const vehicles=getVehicles();
  document.getElementById("statBookings").textContent=bookings.length;
  document.getElementById("statRevenue").textContent=money(totalRevenue());
  document.getElementById("statUsers").textContent=getUsers().length;
  document.getElementById("statFleet").textContent=vehicles.length;

  document.getElementById("adminBookings").innerHTML=bookings.length?('<table class="admin-table"><thead><tr><th>ID</th><th>Customer</th><th>Car</th><th>Dates</th><th>Total</th><th>Status</th><th></th></tr></thead><tbody>'+
    bookings.map(b=>'<tr><td>'+b.id+'</td><td>'+(b.name||b.userEmail)+'</td><td>'+b.carSnapshot.brand+' '+b.carSnapshot.model+'</td><td>'+fmtDate(b.date)+' → '+fmtDate(b.returnDate)+'</td><td>'+money(b.total)+'</td><td>'+bookingStatus(b)+'</td>'+
    '<td>'+(b.status!=="Cancelled"?('<button class="btn btn-outline" style="padding:6px 10px" onclick="cancelBooking(\''+b.id+'\');renderAdmin()">Cancel</button>'):"—")+'</td></tr>').join("")+
  '</tbody></table>'):'<p class="muted">No bookings yet.</p>';

  document.getElementById("adminFleet").innerHTML='<table class="admin-table"><thead><tr><th>Car</th><th>Type</th><th>Price/day</th><th>Demand</th><th></th></tr></thead><tbody>'+
    vehicles.map(c=>'<tr><td>'+c.brand+' '+c.model+'</td><td>'+c.type+'</td><td>'+money(c.price)+'</td><td>'+c.demand+'</td><td><button class="btn btn-outline" style="padding:6px 10px" onclick="deleteVehicle('+c.id+');renderAdmin()">Remove</button></td></tr>').join("")+
  '</tbody></table>';

  document.getElementById("addVehicleForm").addEventListener("submit",e=>{
    e.preventDefault();
    addVehicle({
      brand:document.getElementById("vBrand").value,model:document.getElementById("vModel").value,
      type:document.getElementById("vType").value,price:Number(document.getElementById("vPrice").value),
      seats:Number(document.getElementById("vSeats").value)||5,trans:document.getElementById("vTrans").value,
      fuel:document.getElementById("vFuel").value,image:"assets/cars/creta.png",demand:"normal"
    });
    e.target.reset();renderAdmin();showToast("Vehicle added to fleet");
  });
}

/* ---------- 25. Boot ---------- */
document.addEventListener("DOMContentLoaded",initGlobalUI);
document.getElementById("searchForm")?.addEventListener("submit",e=>{
  e.preventDefault();
  const loc=document.getElementById("location")?document.getElementById("location").value:"";
  location.href="cars.html"+(loc?("?loc="+encodeURIComponent(loc)):"");
});
