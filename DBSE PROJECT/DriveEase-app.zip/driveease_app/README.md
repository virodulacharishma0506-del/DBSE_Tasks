# DriveEase — Car Rentals and Mobility App

Frontend prototype for a self-service car rental and mobility platform, built for the
"Relational Database Engineering" course project. All data (users, bookings, reviews,
fleet, notifications) is simulated in the browser with `localStorage`, standing in for
the relational tables the full system would use (Users, Vehicles, Bookings, Payments,
Reviews).

## Run
1. Extract the ZIP.
2. Open `index.html` in a browser.
3. No backend or installation is required.

## Main flow
Home → Search / Recommendations → Car Details → Compare → Booking (+ licence upload)
→ Payment (+ coupon) → Confirmation → Self-Service (live tracking) → My Bookings

## Features
- **Accounts** — real register/login backed by a `localStorage` users table, session-aware
  navbar (avatar, logout), and a demo admin login (`admin@driveease.com` / `admin123`).
- **Smart search & recommendations** — location-aware search, sort by rating/price,
  a "Recommended for you" row driven by wishlist/booking history.
- **Compare cars** — select up to 3 vehicles and view a side-by-side spec comparison.
- **Ratings & reviews** — star ratings and written reviews per car, with a live average.
- **Wishlist / Favourites** — heart any car, view them all on a dedicated page.
- **Realistic pricing** — day-based totals, demand-based surge pricing, and coupon codes
  (`DRIVE10`, `WELCOME20`, `STUDENT15`) applied at checkout.
- **Digital document verification** — driving-licence upload step before payment.
- **Notifications** — an in-app notification centre for booking and account events.
- **Loyalty programme** — points per booking with Bronze/Silver/Gold/Platinum tiers.
- **My Bookings** — full booking history with Upcoming/Ongoing/Completed/Cancelled status
  and cancellation.
- **Self-service pickup** — digital pass plus a simulated live vehicle-tracking map and ETA.
- **Admin dashboard** — revenue/booking/user/fleet stats, booking status management, and
  vehicle CRUD (add/remove fleet vehicles).
- **Light / dark theme toggle**, persisted across visits.

## Included screens
Home · Login / Register · Car listing + filters · Car details + reviews · Compare ·
Booking · Payment · Booking confirmation · Self-service pass · My bookings · Favourites ·
Profile & loyalty · Admin dashboard

## Technologies
HTML5, CSS3, vanilla JavaScript, `localStorage` (as an in-browser relational-style store).

## Notes
This is a frontend prototype. Payment, licence verification, and GPS tracking are
simulated and do not process real payments, verify real documents, or track real vehicles.
